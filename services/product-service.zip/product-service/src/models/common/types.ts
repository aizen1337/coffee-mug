
export interface IModel {
  id: number;
  created: Date;
}
